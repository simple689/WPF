﻿
namespace SpeedShark2.Navigation
{
	internal static class WindowsMessages  {
		internal static int WM_MOUSEWHEEL = 0x20A;
	}
}
