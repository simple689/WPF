# MinePackage
Fork of Unity 5 Minepackage http://sourceforge.net/projects/minepackage/

## Getting started
 
 * Open the project in Unity 5
 * Open Scene1 and hit play
