﻿This sample shows an allergens concentration in some of the cities in Russia.
The data for this sample was taken from http://www.allergology.ru/,
web site which tracks allergens concentration.