﻿AnimationSample

This is a sample application for DynamicDataDisplay charting library.

This sample shows how to make animated plot by manually updating data source, bound to LineGraph.